import os

#Grammar Words
subjects = []
conjunctions_coordinative = []
conjunctions_correlative = []
conjunctions_subordinative = []
verbs = []
nouns = []

file = open("./grammar_words/coordinating_conjunctions.txt","r")
conjunctions_coordinative = file.readlines()
file.close()

file = open("./grammar_words/correlative_conjunctions.txt","r")
conjunctions_correlative = file.readlines()
file.close()

file = open("./grammar_words/subordinative_conjunctions.txt","r")
conjunctions_subordinative = file.readlines()
file.close()

file = open("./grammar_words/verbs.txt","r")
verbs = file.readlines()
file.close()

file = open("./grammar_words/nouns.txt","r")
nouns = file.readlines()
file.close()

file = open("./grammar_words/subjects.txt","r")
subjects = file.readlines() + nouns
file.close()

#words
positive_words = []
negative_words = []
offensive_words = []

file = open("./words/positive_words.txt","r")
positive_words = file.readlines() 
file.close()

file = open("./words/negative_words.txt","r")
negative_words = file.readlines() 
file.close()

file = open("./words/offensive_words.txt","r")
offensive_words = file.readlines()
file.close()

#Refering to
myself = []
others = []

file = open("./refering/myself.txt","r")
myself = file.readlines() 
file.close()
file = open("./refering/others.txt","r")
others = file.readlines()
file.close()

#grammar rules
grammar_rule_dir = "./grammar_rules/"
grammar_rule_files = os.listdir(grammar_rule_dir)

#Questions
file = open("./grammar_rules/a_question.txt","r")
question_syntax = file.readlines()
file.close()

def find_subject(sentance):
    divided_sentance = find_grammar_rule(sentance)
    if len(divided_sentance) > 1:
        return divided_sentance
    else:
        return [divided_sentance[0],divided_sentance[0]]
 
def a_question(sentance):
    divided_sentance = find_grammar_rule(sentance)
    if len(divided_sentance) > 1:
        pass
    else:
        divided_sentance = divided_sentance[0]
    #print("div:"+str(divided_sentance))    
    for item in divided_sentance:
        for q_syntax in question_syntax:
            q_syntax = q_syntax.replace("{","").replace("}","").replace(" ","").split("+")[0]
            if "/" in q_syntax:
                for q_word in q_syntax.split("/"):
                    if q_word == item.split(" ")[0]:
                        return "question"
            elif "?" in q_syntax:
                if "?" == item.split(" ")[-1]:
                    return "question"
            else:
                return "NULL"
 
def find_context(sentance):
    context = []
    context_rating = {}
    context_rating["myself"] = 0
    context_rating["others"] = 0
    context_rating["start"] = "NULL"
    for word in sentance.split(" "):
        for refer_tmp in myself:
            if word + "\n" == refer_tmp:
                context.append("myself")                
        for refer_tmp in others:
            if word + "\n" == refer_tmp:
                context.append("others")
                
    for context_item in context:
        if context_item == "myself":
            context_rating["myself"] = context_rating["myself"] + 1
        if context_item == "others":
            context_rating["others"] = context_rating["others"] + 1
            
    for context_item in context:
        if context_item == "myself":
            context_rating["start"] = "myself"
            break
        elif context_item == "others":
            context_rating["start"] = "others" 
            break
    return context_rating
    
def find_sentiment(data_dict,context_rating):
    emotion = []
    try:
        if context_rating["myself"] > context_rating["others"]:
            if data_dict["negative"] != "NULL":
                emotion.append("sad")
            if data_dict["positive"] != "NULL":  
                emotion.append("happy")
            if data_dict["offensive"] != "NULL":
                if data_dict["positive"] != "NULL":
                    emotion.append("excited")            
                elif data_dict["negative"] != "NULL":
                    emotion.append("depression")
                if data_dict["question"] != "NULL":
                    emotion.append("depression")
                    emotion.append("confused")
                if data_dict["positive"] != "NULL":
                    emotion.append("excited")
            if data_dict["question"] != "NULL":
                if data_dict["offensive"] != "NULL":
                    emotion.append("depression")
                if data_dict["negative"] != "NULL":
                    emotion.append("sad")
                if data_dict["positive"] != "NULL":
                    emotion.append("happy")                
        if context_rating["myself"] < context_rating["others"]:
            if data_dict["negative"] != "NULL":
                emotion.append("anger")
            elif data_dict["positive"] != "NULL":  
                emotion.append("appreciating")
            if data_dict["offensive"] != "NULL":
                emotion.append("anger")
                if data_dict["positive"] != "NULL":
                    emotion.append("excited")            
                if data_dict["negative"] != "NULL":
                    emotion.append("bad mood")
                if data_dict["question"] != "NULL":
                    emotion.append("anger")
            if data_dict["question"] != "NULL":
                if data_dict["offensive"] != "NULL":
                    emotion.append("anger")
                if data_dict["negative"] != "NULL":
                    emotion.append("bad mood")
                if data_dict["positive"] != "NULL":
                    emotion.append("good mood")
        
        if context_rating["myself"] == context_rating["others"]:
            if context_rating["start"] == "others":
                if data_dict["negative"] != "NULL":
                    emotion.append("sad")
                elif data_dict["positive"] != "NULL":  
                    emotion.append("happy")
                if data_dict["offensive"] != "NULL":
                    emotion.append("depression")
                    if data_dict["negative"] != "NULL":
                        emotion.append("depression")
                    if data_dict["question"] != "NULL":
                        emotion.append("depression")
                        emotion.append("confused")
                    if data_dict["positive"] != "NULL":
                        emotion.append("excited")
                if data_dict["question"] != "NULL":
                    if data_dict["offensive"] != "NULL":
                        emotion.append("depression")
                    if data_dict["negative"] != "NULL":
                        emotion.append("sad")
                    if data_dict["positive"] != "NULL":
                        emotion.append("happy") 
            if context_rating["start"] == "myself":
                if data_dict["negative"] != "NULL":
                    emotion.append("anger")
                elif data_dict["positive"] != "NULL":  
                    emotion.append("appreciating")
                if data_dict["offensive"] != "NULL":
                    emotion.append("anger")
                    if data_dict["positive"] != "NULL":
                        emotion.append("excited")            
                    elif data_dict["negative"] != "NULL":
                        emotion.append("bad mood")
                    if data_dict["question"] != "NULL":
                        emotion.append("anger")
                if data_dict["question"] != "NULL":
                    if data_dict["offensive"] != "NULL":
                        emotion.append("anger")
                    if data_dict["negative"] != "NULL":
                        emotion.append("bad mood")
                    if data_dict["positive"] != "NULL":
                        emotion.append("good mood") 
    except:
        if data_dict["refering"] == "others":
            if data_dict["offensive"] != "NULL":
                emotion.append("frustrated")
                if data_dict["negative"] != "NULL":
                    emotion.append("anger")
            if data_dict["negative"] != "NULL":
                emotion.append("bad mood")
        if data_dict["refering"] == "myself":
            if data_dict["question"] != "NULL":
                if data_dict["positive"] != "NULL":
                    emotion.append("confused")
                if data_dict["negative"] != "NULL":
                    emotion.append("confused")        
    return emotion
    
def find_noun():
    pass

def find_verb():
    pass
    
def find_grammar_rule(sentance):
    divided_sentance = []
    for rule in grammar_rule_files:
        file = open(grammar_rule_dir+rule)
        grammar_rule_syntax = file.readlines()
        file.close()
        for syntax in grammar_rule_syntax:
            syntax_components = syntax.replace(" ","").split("+")
            for word in sentance.split(" "):
                for component in syntax_components:
                    component = component.replace("{","").replace("}","")
                    if "/" in component:
                        for sub_component in  component.split("/"):
                            if word == sub_component:
                                if sentance.split(word) not in divided_sentance:
                                    appendable = sentance.split(word)
                                    if len(appendable) > 1:
                                        appendable[0] = appendable[0] + word
                                    divided_sentance.append(appendable)
                    else:
                        if word == component:
                                if sentance.split(word) not in divided_sentance:
                                    appendable = sentance.split(word)
                                    if len(appendable) > 1:
                                        appendable[0] = appendable[0] + word
                                    divided_sentance.append(appendable)
    if len(divided_sentance) == 0:
        return [sentance]
    else:
        #print(divided_sentance)
        return divided_sentance[0]                
                    
    
def find_if_offensive(words):
    flag =""
    words = words.split(" ")
    for word in words:
        if word.replace(" ","") + "\n" in offensive_words:
            flag = "offensive"
        else:
            pass
    if flag == "offensive":
        return "offensive"
    else:
        return "NULL"

def find_if_postive(words):
    flag =""
    words = words.split(" ")
    for word in words:
        if word.replace(" ","") + "\n" in positive_words:
            flag = "positive"
        else:
            pass
    if flag == "positive":
        return "positive"
    else:
        return "NULL"
  
def find_if_negative(words):
    flag =""
    words = words.split(" ")
    for word in words:
        if word.replace(" ","") + "\n" in negative_words:
            flag = "negative"
        else:
            pass
    if flag == "negative":
        return "negative"
    else:
        return "NULL"

def find_refering(possible_subjects):
    refer_tmp = ""
    #print(possible_subjects)
    for me in myself:
        me = me.replace("\n","").lower()
        for word in possible_subjects.split(" "):
            if me == word:
                #print("me:"+me)
                #print(word)
                refer_tmp = "myself" + " "
    for other in others:
        other = other.replace("\n","").lower()
        if "[nouns]" in other:
            other = other.replace(" ","").split("+")[0]
            #print("other:"+other)
            for word in possible_subjects.split(" "):
                if other == word:
                    refer_tmp = "others" + " "
        else:
            other = other.replace(" ","").replace("\n","").lower()
            for word in possible_subjects.split(" "):
                if other == word:
                    refer_tmp = "others" + " "            
    return refer_tmp
    
def input_text(sentance):
    sentance = input("Enter something : ")
    sentance_lower = sentance.lower()
    subject = find_subject(sentance_lower)
    #print("sub:"+str(subject))
    if_question = a_question(sentance)
    refering = "NULL"
    if_offensive = "NULL"
    if_positive = "NULL"
    if_negative = "NULL"
    if if_question == "NULL":
        refering = find_refering(subject[0])
        if_offensive = find_if_offensive(subject[1])
        if_positive = find_if_postive(subject[1])
        if_negative = find_if_negative(subject[1])
    else:
        refering = find_refering(subject[1])
        if_offensive = find_if_offensive(subject[1])
        if if_offensive == "NULL":
            if_offensive = find_if_offensive(subject[0])
        if_positive = find_if_postive(subject[1])
        if_negative = find_if_negative(subject[1])
        
    context = find_context(sentance) 
    
    data_dict = {}
    
    data_dict["refering"] = refering
    data_dict["offensive"] = if_offensive
    data_dict["positive"] = if_positive
    data_dict["negative"] = if_negative
    data_dict["question"] = if_question
    data_dict["context"] = context
    emotion = find_sentiment(data_dict,context)
    emotion_tags = []
    #identify tags
    for tag in emotion:
        if tag not in emotion_tags:
            emotion_tags.append(tag)
    emotional_frequency = {}
    #initialise
    for tag in emotion_tags:
        emotional_frequency[tag] = 0
    #count frequency    
    for tag in emotion:
        emotional_frequency[tag] = emotional_frequency[tag] + 1

    print("basic features:")
    print(data_dict)        
    print("emotion frequency:")
    print(emotional_frequency)

while True:
    input_text("sample")           